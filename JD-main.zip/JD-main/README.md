免责声明: 本仓库项目中所涉及的任何解锁和解密分析脚本，仅用于测试和学习研究，不保证其合法性，准确性，完整性和有效性，请根据情况自行判断。请勿将本项目的任何内容用于商业或非法途径，否则后果由使用者自负。如果您认为该项目的内容可能涉嫌侵犯其权利，请与我联系，我会尽快删除文件。如果您使用或复制了本仓库项目中的任何内容，则视为您已接受此免责声明。
搜集整理自各位大佬

【青龙】拉取仓库命令
```
ql repo https://github.com/asd920/Auto.git "jd_|jx_|getJDCookie" "backUp|icon" "^jd[^_]|USER|sendNotify|sign_graphics_validate|JDJR|JDSign|JD_DailyBonus"
```
* > 上面命令拉取错误的使用这个：`ql repo https://gitee.com/asd920/Auto.git "jd_|jx_|getJDCookie" "backUp|icon" "^jd[^_]|USER|sendNotify|sign_graphics_validate|JDJR|JDSign|JD_DailyBonus"`

如遇到仓库更新失败，可以给宿主机挂代理并注释 config.sh 文件中的文件中的GithubProxyUrl参数解决，无法挂代理的可以修改青龙 config.sh 文件中的GithubProxyUrl参数为 https://pd.zwc365.com/ 或 https://pd.zwc365.com/cfworker/ 临时解决。

* > 腾讯云函数部署建议阅读@hshx123大佬的[教程](https://66ccff.work/teach/jd.html)【推荐】.[旧教程](./backUp/tencentscf.md)【备用】

* > [elecV2P](https://github.com/elecV2/elecV2P) 部署【随缘维护，建议转战➟[Docker](https://www.runoob.com/docker/windows-docker-install.html) [青龙](https://github.com/whyour/qinglong)】
    * 安装教程：[点此查看](https://github.com/elecV2/elecV2P-dei/blob/master/docs/01-overview.md)  
    * 订阅任务：`https://ghproxy.com/https://raw.githubusercontent.com/asd920/Auto/main/jd_task.json`
    * elecV2P相关补充说明：[点此查看](./backUp/elecV2P.md)  

## 自动同步本仓库脚本教程：[点此查看](https://github.com/asd920/Auto/blob/main/backUp/reposync.md)  

- 获取cookie教程可参考：
  
  + [浏览器获取cookie教程](./backUp/GetJdCookie.md)
    
  + [插件获取cookie教程](./backUp/GetJdCookie2.md)
